var btn = document.querySelector('button');

btn.addEventListener('click', function(e){
  console.log('clicked button');
});