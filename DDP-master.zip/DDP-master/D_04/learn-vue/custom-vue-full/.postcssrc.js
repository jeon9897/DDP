// https://github.com/michael-ciniawsky/postcss-load-config

module.exports = {
  "plugins": {
    // 대상 브라우저를 편집하려면 package.json의 "browserslist"필드에 작성하세요.
    "autoprefixer": {}
  }
}
