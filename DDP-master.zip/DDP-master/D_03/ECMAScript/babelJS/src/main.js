let [a, b, c, d] = [1, 2, 3, 4];

let double = x => x * x;

let test = '테스트';

{
  let test = '테스트';
}